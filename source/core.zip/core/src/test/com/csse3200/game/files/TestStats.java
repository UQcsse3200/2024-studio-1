package com.csse3200.game.files;

public class TestStats {
  public int stat1 = 1;
  public int stat2 = 2;
}
