package com.csse3200.game.ai.tasks;

import com.csse3200.game.entities.Entity;

public interface TaskRunner {
  Entity getEntity();
}
